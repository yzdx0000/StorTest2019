#include <iostream>

int print(int test)
{
   if ( ! test )
      return 1;
   else
      return 2;
}
