#!/bin/bash
sh Install_Openmpi.sh
if [[ $? == 0 ]]
then
    source /etc/profile
    export MPI_CC="mpicc"
    sh Install_Mdtest.sh
    if [[ $? == 0 ]]
    then
        echo "install mdtest success"
    else
        echo "install mdtest failed"
    fi
else
    echo "install mpi failed"
    exit
fi

