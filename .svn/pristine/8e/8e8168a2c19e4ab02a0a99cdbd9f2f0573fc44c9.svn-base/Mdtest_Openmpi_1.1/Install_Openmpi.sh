#!/bin/bash
mpiver=openmpi-2.1.3
tar vxzf ${mpiver}.tar.gz
cd ${mpiver}
./configure --prefix=/usr/local/${mpiver}
make all install
echo "/usr/local/${mpiver}/lib" >> /etc/ld.so.conf
/sbin/ldconfig
echo "export PATH=/usr/local/${mpiver}/bin:$PATH" >> /etc/profile
echo "export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/${mpiver}/lib" >> /etc/profile
source /etc/profile
cd examples
make
mpirun --allow-run-as-root -np 2 hostname
cd ../..
rm -rf ${mpiver}
