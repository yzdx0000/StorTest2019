#!/bin/bash
mdtest_ver=mdtest-1.9.3
mkdir ${mdtest_ver}
tar vxf ${mdtest_ver}.tgz -C ${mdtest_ver}
cd ${mdtest_ver}
export MPI_CC="mpicc"
make
mv mdtest ../
cd ..
rm -rf ${mdtest_ver}
